# Empty class, see mail to Tom Hofkens

class Ticket:
    pass