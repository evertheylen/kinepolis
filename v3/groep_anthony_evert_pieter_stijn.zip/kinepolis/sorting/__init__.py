from .bubble import bubblesort
from .merge import mergesort
from .heaps import heapsort
from .insertion import insertionsort
from .quick import quicksort
from .selection import selectionsort
from .tree import treesort

# no radix